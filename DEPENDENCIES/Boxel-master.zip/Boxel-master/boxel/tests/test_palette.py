import numpy as np

def test_swap():
    assert True == True
    '''
    actual = np.asarray([   [255, 255, 255],
                            [196, 125, 189],
                            [196, 125, 189],
                            [201, 203, 216]])
    RGB.ms_paint(actual)
    expected = np.asarray([ [250, 255, 255],
                            [160, 160, 164],
                            [192, 192, 192]])
    print RGB.palette_map
    np.testing.assert_array_equal(actual, expected)
    '''

